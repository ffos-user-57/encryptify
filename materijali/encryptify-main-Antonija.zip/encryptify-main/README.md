# encryptify
Encryptify is a website that teaches about encryption + There is no database, nor does it store your information  in any way- it can convert your password to md5 and sha1.  

# installation
Get XAMPP - run apache on it - open your htdocs and dump the encryptify folder inside - Done.

# Members
FFOS students - F.O. , A. K., E.S. - Projektni rad - IT 
